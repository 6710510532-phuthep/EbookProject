-- Novel Rental System Database Schema v4 (Meb Theme + Dark Mode)
CREATE DATABASE IF NOT EXISTS `novel_db` CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;
USE `novel_db`;

-- Users Table
CREATE TABLE IF NOT EXISTS `users` (
  `user_id` INT AUTO_INCREMENT PRIMARY KEY,
  `username` VARCHAR(50) NOT NULL UNIQUE,
  `email` VARCHAR(100) NOT NULL UNIQUE,
  `password_hash` VARCHAR(255) NOT NULL,
  `role` ENUM('user', 'admin') DEFAULT 'user',
  `wallet_balance` DECIMAL(10,2) DEFAULT 0.00,
  `created_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- Novels Table
CREATE TABLE IF NOT EXISTS `novels` (
  `novel_id` INT AUTO_INCREMENT PRIMARY KEY,
  `title` VARCHAR(255) NOT NULL,
  `author` VARCHAR(100) NOT NULL,
  `category` VARCHAR(50) NOT NULL,
  `cover_img` VARCHAR(255) DEFAULT 'https://images.unsplash.com/photo-1543002588-bfa74002ed7e?w=500&q=80',
  `synopsis` TEXT,
  `content` LONGTEXT NOT NULL,
  `price_per_day` DECIMAL(8,2) NOT NULL,
  `rating` DECIMAL(2,1) DEFAULT 4.8,
  `status` ENUM('active', 'inactive') DEFAULT 'active',
  `created_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- Rentals Table
CREATE TABLE IF NOT EXISTS `rentals` (
  `rental_id` INT AUTO_INCREMENT PRIMARY KEY,
  `user_id` INT NOT NULL,
  `novel_id` INT NOT NULL,
  `rent_days` INT NOT NULL,
  `total_price` DECIMAL(10,2) NOT NULL,
  `rent_date` DATETIME DEFAULT CURRENT_TIMESTAMP,
  `expire_date` DATETIME NOT NULL,
  `status` ENUM('active', 'expired', 'hidden') DEFAULT 'active',
  `created_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  FOREIGN KEY (`user_id`) REFERENCES `users`(`user_id`) ON DELETE CASCADE,
  FOREIGN KEY (`novel_id`) REFERENCES `novels`(`novel_id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- Sample Users
INSERT INTO `users` (`username`, `email`, `password_hash`, `role`, `wallet_balance`) 
VALUES ('admin', 'admin@example.com', '$2y$10$4.aU2uWv3R.43s1C8M80zeY9fN2hQYI/U8zWbK6xQ1E1m/sUfE3Sm', 'admin', 1000.00)
ON DUPLICATE KEY UPDATE `user_id`=`user_id`;

INSERT INTO `users` (`username`, `email`, `password_hash`, `role`, `wallet_balance`) 
VALUES ('demo_user', 'user@example.com', '$2y$10$4.aU2uWv3R.43s1C8M80zeY9fN2hQYI/U8zWbK6xQ1E1m/sUfE3Sm', 'user', 500.00)
ON DUPLICATE KEY UPDATE `user_id`=`user_id`;

-- Sample Novels with HD Covers & Ratings
INSERT INTO `novels` (`title`, `author`, `category`, `cover_img`, `synopsis`, `content`, `price_per_day`, `rating`) VALUES
('จุดกำเนิดมหาศึกแฟนตาซี', 'กวีชุดดำ', 'Fantasy', 'https://images.unsplash.com/photo-1518709268805-4e9042af9f23?w=500&q=80', 'เรื่องราวการเดินทางของอัศวินรุ่นเยาว์สู่ดินแดนต้องห้ามเพื่อตามหาศิลาเวทมนตร์สูญหาย', 'บทที่ 1: รุ่งอรุณแห่งโชคตากรรม

ท่ามกลางสายลมหนาวพัดผ่านหุบเขาอสูร ยามเช้าตรู่ของหมู่บ้านริมชายแดนเต็มไปด้วยหมอกหนาแน่น...', 15.00, 4.9),
('ความรักในเงาสลัว', 'ดารากลางคืน', 'Romance', 'https://images.unsplash.com/photo-1516589178581-6cd7833ae3b2?w=500&q=80', 'ความสัมพันธ์ลับๆ ระหว่างสองหัวใจที่ตัดกันด้วยหน้าที่และความจริงใจ', 'บทที่ 1: เสียง drops บนกระจก

แสงไฟจากคาเฟ่ริมถนนส่องสว่างกระทบละอองฝน รสชาติของกาแฟดำยังคงขมติดลิ้น...', 10.00, 4.8),
('รหัสลับห้องปิดตาย', 'เงาสืบสวน', 'Mystery', 'https://images.unsplash.com/photo-1509198397868-475647b2a1e5?w=500&q=80', 'คดีฆาตกรรมปริศนาในคฤหาสน์กลางป่าลึกที่ไร้ร่องรอยผู้บุกรุก', 'บทที่ 1: คืนฝนตกและเสียงนาฬิกาโบราณ

เสียงตีกระทบของนาฬิกาลูกตุ้มดังกังวาน 12 ครั้ง ร่างของชายหนุ่มนอนแน่นิ่งอยู่บนเก้าอี้...', 12.00, 4.7),
('พลิกชะตาจักรพรรดิเวท', 'มังกรหยก', 'Fantasy', 'https://images.unsplash.com/photo-1514539079130-25950c84af65?w=500&q=80', 'มหากาพย์การต่อสู้เพื่อทวงคืนบัลลังก์ของจักรพรรดิแห่งอักขระเวท', 'บทที่ 1: การตื่นขึ้นในสุสานแร่ออรา

ละอองแสงสีฟ้าครามลอยอบอวลไปทั่วสุสานโบราณ...', 18.00, 5.0);