<?php
require_once 'header.php';
require_login();

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $token = $_POST['csrf_token'] ?? '';
    if (!verify_csrf($token)) {
        die("CSRF Token Verification Failed.");
    }

    $amount = floatval($_POST['amount'] ?? 0);
    if ($amount > 0) {
        $stmt = $pdo->prepare("UPDATE users SET wallet_balance = wallet_balance + ? WHERE user_id = ?");
        $stmt->execute([$amount, $_SESSION['user_id']]);
        header("Location: profile.php");
        exit();
    }
}
?>

<div class="container pt-4">
    <div class="row justify-content-center">
        <div class="col-md-5">
            <div class="card border-0 shadow-sm rounded-4 overflow-hidden meb-detail-card">
                <div class="card-header bg-meb-gradient text-white fw-bold fs-5 py-3 text-center border-0">
                    <i class="fa-solid fa-wallet me-2"></i>เติมเงินเข้า Wallet จำลอง
                </div>
                <div class="card-body p-4">
                    <form action="topup.php" method="POST">
                        <input type="hidden" name="csrf_token" value="<?= csrf_token() ?>">
                        <div class="mb-3">
                            <label class="form-label fw-bold meb-text-main">เลือกจำนวนเงินเติม:</label>
                            <div class="row g-2 mb-3">
                                <div class="col-4"><button type="button" class="btn btn-outline-meb w-100 rounded-pill topup-amount-btn" data-val="100">฿100</button></div>
                                <div class="col-4"><button type="button" class="btn btn-outline-meb w-100 rounded-pill topup-amount-btn" data-val="300">฿300</button></div>
                                <div class="col-4"><button type="button" class="btn btn-outline-meb w-100 rounded-pill topup-amount-btn" data-val="500">฿500</button></div>
                            </div>
                            <input type="number" step="0.01" min="10" name="amount" id="topupAmountInput" class="form-control form-control-lg rounded-3 meb-input" placeholder="ระบุจำนวนเงิน (บาท)" required>
                        </div>
                        <button type="submit" class="btn btn-meb-orange btn-lg w-100 rounded-pill fw-bold text-white shadow-sm mt-2"><i class="fa-solid fa-check me-1"></i>ยืนยันเติมเงิน</button>
                    </form>
                </div>
            </div>
        </div>
    </div>
</div>

<script>
document.addEventListener('DOMContentLoaded', function() {
    const amountInput = document.getElementById('topupAmountInput');
    document.querySelectorAll('.topup-amount-btn').forEach(btn => {
        btn.addEventListener('click', function() {
            amountInput.value = this.getAttribute('data-val');
        });
    });
});
</script>

<?php require_once 'footer.php'; ?>