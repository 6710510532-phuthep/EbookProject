</div> <!-- End main-wrapper -->

<footer class="meb-footer py-4 mt-5 border-top">
    <div class="container text-center">
        <div class="d-flex justify-content-center align-items-center gap-2 mb-2">
            <div class="meb-logo-icon sm"><i class="fa-solid fa-book-open"></i></div>
            <span class="fw-bold fs-5 meb-footer-brand">Book<span class="text-meb-orange">Rent</span></span>
        </div>
        <p class="text-muted small mb-1">&copy; <?= date('Y') ?> BookRent — ระบบเช่านิยายออนไลน์ดีไซน์สไตล์ Meb Market</p>
        <small class="text-secondary">อ่านง่าย ชำระเงินสะดวก รองรับ Dark Mode และทุกอุปกรณ์</small>
    </div>
</footer>

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
<script src="assets/js/main.js"></script>
</body>
</html>