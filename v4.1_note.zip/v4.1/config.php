<?php
// =========================================================================
// การตั้งค่าค่าคงที่ (CONSTANTS) สำหรับเชื่อมต่อฐานข้อมูล MYSQL
// =========================================================================
define('DB_HOST', 'localhost'); // ชื่อโฮสต์ของฐานข้อมูล (เช่น localhost)
define('DB_USER', 'root');      // ชื่อผู้ใช้งานฐานข้อมูล (ค่าเริ่มต้นของ XAMPP/Laragon คือ root)
define('DB_PASS', '');          // รหัสผ่านฐานข้อมูล (ค่าเริ่มต้นปกติจะเป็นค่าว่าง)
define('DB_NAME', 'novel_db');  // ชื่อฐานข้อมูลที่ใช้งาน

// =========================================================================
// การสร้างการเชื่อมต่อผ่าน PDO (PHP DATA OBJECTS)
// =========================================================================
try {
    // สร้าง Object PDO สำหรับเชื่อมต่อ MySQL พร้อมกำหนด charset เป็น utf8mb4 เพื่อรองรับภาษาไทยและ Emoji
    $pdo = new PDO("mysql:host=" . DB_HOST . ";dbname=" . DB_NAME . ";charset=utf8mb4", DB_USER, DB_PASS, [
        PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION,       // แจ้งเตือน Error ในรูปแบบ Exception
        PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC, // คืนค่าข้อมูลแบบ Associative Array (ชื่อคอลัมน์)
        PDO::ATTR_EMULATE_PREPARES => false,              // ปิดการจำลองการเตรียมคำสั่ง เพื่อป้องกัน SQL Injection
    ]);
} catch (PDOException $e) {
    // หากเชื่อมต่อไม่สำเร็จ ให้หยุดการทำงานทันทีและแสดงข้อความแจ้งเตือน Error
    die("Database Connection Failed: " . $e->getMessage());
}
?>