</div> <!-- ปิดแท็ก main-wrapper ที่เปิดไว้จากไฟล์ header.php เพื่อคุมขอบเขตเนื้อหาหลัก[cite: 125, 133] -->

<!-- ========================================================================= -->
<!-- ส่วนท้ายของเว็บไซต์ (FOOTER) สไตล์ MEB MARKET[cite: 125] -->
<!-- ========================================================================= -->
<footer class="meb-footer py-4 mt-5 border-top">
    <div class="container text-center">
        
        <!-- โลโก้และชื่อแบรนด์ส่วน Footer[cite: 125] -->
        <div class="d-flex justify-content-center align-items-center gap-2 mb-2">
            <div class="meb-logo-icon sm"><i class="fa-solid fa-book-open"></i></div>
            <span class="fw-bold fs-5 meb-footer-brand">Book<span class="text-meb-orange">Rent</span></span>
        </div>
        
        <!-- ข้อความสิทธิ์และดึงปี ค.ศ. ปัจจุบันแบบไดนามิกด้วย date('Y')[cite: 125] -->
        <p class="text-muted small mb-1">&copy; <?= date('Y') ?> BookRent — ระบบเช่านิยายออนไลน์ดีไซน์สไตล์ Meb Market</p>
        <small class="text-secondary">อ่านง่าย ชำระเงินสะดวก รองรับ Dark Mode และทุกอุปกรณ์</small>
        
    </div>
</footer>

<!-- ========================================================================= -->
<!-- นำเข้า JavaScript ลิขสิทธิ์และสคริปต์หลักของระบบ[cite: 125] -->
<!-- ========================================================================= -->
<!-- นำเข้า Bootstrap 5.3 JavaScript Bundle (รวม Popper.js สำหรับทำ Dropdown / Modal)[cite: 125] -->
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>

<!-- นำเข้าไฟล์ main.js สำหรับควบคุมระบบสลับ Dark Mode, ระบบค้นหา และระบบคำนวณราคา[cite: 125] -->
<script src="assets/js/main.js"></script>

</body>
</html>