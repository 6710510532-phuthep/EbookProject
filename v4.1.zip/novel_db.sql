-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Oct 22, 2026 at 11:39 AM
-- Server version: 10.4.32-MariaDB
-- PHP Version: 8.2.12

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `novel_db`
--

-- --------------------------------------------------------

--
-- Table structure for table `novels`
--

CREATE TABLE `novels` (
  `novel_id` int(11) NOT NULL,
  `title` varchar(255) NOT NULL,
  `author` varchar(100) NOT NULL,
  `category` varchar(50) NOT NULL,
  `cover_img` varchar(255) DEFAULT 'https://images.unsplash.com/photo-1543002588-bfa74002ed7e?w=500&q=80',
  `synopsis` text DEFAULT NULL,
  `content` longtext NOT NULL,
  `price_per_day` decimal(8,2) NOT NULL,
  `rating` decimal(2,1) DEFAULT 4.8,
  `status` enum('active','inactive') DEFAULT 'active',
  `created_at` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `novels`
--

INSERT INTO `novels` (`novel_id`, `title`, `author`, `category`, `cover_img`, `synopsis`, `content`, `price_per_day`, `rating`, `status`, `created_at`) VALUES
(1, 'จุดกำเนิดมหาศึกแฟนตาซี', 'กวีชุดดำ', 'Fantasy', 'https://images.unsplash.com/photo-1518709268805-4e9042af9f23?w=500&amp;q=80', 'เรื่องราวการเดินทางของอัศวินรุ่นเยาว์สู่ดินแดนต้องห้ามเพื่อตามหาศิลาเวทมนตร์สูญหาย', 'บทที่ 1: รุ่งอรุณแห่งโชคตากรรม\r\n\r\nท่ามกลางสายลมหนาวพัดผ่านหุบเขาอสูร ยามเช้าตรู่ของหมู่บ้านริมชายแดนเต็มไปด้วยหมอกหนาแน่น...', 15.00, 4.9, 'active', '2026-10-20 15:02:44'),
(2, 'ความรักในเงาสลัว', 'ดารากลางคืน', 'Romance', 'https://images.unsplash.com/photo-1516589178581-6cd7833ae3b2?w=500&q=80', 'ความสัมพันธ์ลับๆ ระหว่างสองหัวใจที่ตัดกันด้วยหน้าที่และความจริงใจ', 'บทที่ 1: เสียง drops บนกระจก\n\nแสงไฟจากคาเฟ่ริมถนนส่องสว่างกระทบละอองฝน รสชาติของกาแฟดำยังคงขมติดลิ้น...', 10.00, 4.8, 'active', '2026-10-20 15:02:44'),
(3, 'รหัสลับห้องปิดตาย', 'เงาสืบสวน', 'Mystery', 'https://images.unsplash.com/photo-1509198397868-475647b2a1e5?w=500&q=80', 'คดีฆาตกรรมปริศนาในคฤหาสน์กลางป่าลึกที่ไร้ร่องรอยผู้บุกรุก', 'บทที่ 1: คืนฝนตกและเสียงนาฬิกาโบราณ\n\nเสียงตีกระทบของนาฬิกาลูกตุ้มดังกังวาน 12 ครั้ง ร่างของชายหนุ่มนอนแน่นิ่งอยู่บนเก้าอี้...', 12.00, 4.7, 'active', '2026-10-20 15:02:44'),
(4, 'พลิกชะตาจักรพรรดิเวท', 'มังกรหยก', 'Fantasy', 'https://images.unsplash.com/photo-1514539079130-25950c84af65?w=500&q=80', 'มหากาพย์การต่อสู้เพื่อทวงคืนบัลลังก์ของจักรพรรดิแห่งอักขระเวท', 'บทที่ 1: การตื่นขึ้นในสุสานแร่ออรา\n\nละอองแสงสีฟ้าครามลอยอบอวลไปทั่วสุสานโบราณ...', 18.00, 5.0, 'active', '2026-10-20 15:02:44'),
(5, 'ไก่ต้มน้ำปลา ง่ายๆ', 'กวีชุดดำ', 'Fantasy', 'https://img.wongnai.com/p/1920x0/2021/09/13/3be1e363fa814b92acf3c75abd053e92.jpg', 'สูตรการทำไก่ต้มน้ำปลาให้เนื้อนุ่มและหอมอร่อย', 'การทำไก่ต้มน้ำปลาให้เนื้อนุ่มและหอมอร่อย ใช้สะโพกไก่ติดน่อง 1-2 ชิ้น ต้มในน้ำเดือดที่ใส่รากผักชี กระเทียม พริกไทยเม็ด ใบเตย น้ำปลาแท้ และน้ำตาลมะพร้าว ใช้ไฟอ่อนต้มประมาณ 30-40 นาทีจนไก่สุกนุ่ม ทานคู่กับน้ำจิ้มซีฟู้ดรสแซ่บ\r\n\r\nส่วนผสมไก่ต้มน้ำปลา\r\n\r\n• สะโพกไก่ติดน่อง 1-2 ชิ้น\r\n• น้ำปลาแท้ 3-4 ช้อนโต๊ะ\r\n• น้ำตาลมะพร้าวหรือน้ำตาลปี๊บ 2 ช้อนโต๊ะ\r\n• รากผักชี 2-3 ราก\r\n• กระเทียมบุบ 4-5 กลีบ\r\n• พริกไทยเม็ด 1 ช้อนชา\r\n• ใบเตย 2-3 ใบ\r\n• ซีอิ๊วดำหวาน 1 ช้อนชา (เพิ่มสีสวย)\r\n• น้ำเปล่าพอท่วมไก่\r\n\r\nวิธีทำไก่ต้มน้ำปลา\r\n\r\n• ตั้งหม้อใส่น้ำเปล่า ใส่รากผักชี กระเทียม พริกไทย และใบเตยลงไป\r\n• ปรุงรสด้วยน้ำปลา น้ำตาลมะพร้าว และซีอิ๊วดำ คนให้ละลายจนเดือด\r\n• นำไก่ลงไปต้ม พอกลับมาเดือดอีกครั้ง ให้หรี่เป็นไฟอ่อน ปิดฝาต้ม 30-45 นาที\r\n• ตักขึ้นสับเป็นชิ้นจัดใส่จาน\r\n\r\nส่วนผสมน้ำจิ้มซีฟู้ด\r\n\r\n• พริกขี้หนูสวน 15-20 เม็ด\r\n• กระเทียมไทย 10 กลีบ\r\n• รากผักชี 1-2 ราก\r\n• น้ำมะนาว 3-4 ช้อนโต๊ะ\r\n• น้ำปลา 2-3 ช้อนโต๊ะ\r\n• น้ำตาลทราย 1 ช้อนชา', 10.00, 4.8, 'active', '2026-10-21 13:29:45'),
(6, 'จุดกำเนิดมหาศึกแฟนตาซี', 'กวีชุดดำ', 'Fantasy', 'https://images.unsplash.com/photo-1518709268805-4e9042af9f23?w=500&q=80', 'เรื่องราวการเดินทางของอัศวินรุ่นเยาว์สู่ดินแดนต้องห้ามเพื่อตามหาศิลาเวทมนตร์สูญหาย', 'บทที่ 1: รุ่งอรุณแห่งโชคตากรรม\n\nท่ามกลางสายลมหนาวพัดผ่านหุบเขาอสูร ยามเช้าตรู่ของหมู่บ้านริมชายแดนเต็มไปด้วยหมอกหนาแน่น...', 15.00, 4.9, 'active', '2026-10-21 13:34:36'),
(7, 'ความรักในเงาสลัว', 'ดารากลางคืน', 'Romance', 'https://images.unsplash.com/photo-1516589178581-6cd7833ae3b2?w=500&q=80', 'ความสัมพันธ์ลับๆ ระหว่างสองหัวใจที่ตัดกันด้วยหน้าที่และความจริงใจ', 'บทที่ 1: เสียง drops บนกระจก\n\nแสงไฟจากคาเฟ่ริมถนนส่องสว่างกระทบละอองฝน รสชาติของกาแฟดำยังคงขมติดลิ้น...', 10.00, 4.8, 'active', '2026-10-21 13:34:36'),
(8, 'รหัสลับห้องปิดตาย', 'เงาสืบสวน', 'Mystery', 'https://images.unsplash.com/photo-1509198397868-475647b2a1e5?w=500&q=80', 'คดีฆาตกรรมปริศนาในคฤหาสน์กลางป่าลึกที่ไร้ร่องรอยผู้บุกรุก', 'บทที่ 1: คืนฝนตกและเสียงนาฬิกาโบราณ\n\nเสียงตีกระทบของนาฬิกาลูกตุ้มดังกังวาน 12 ครั้ง ร่างของชายหนุ่มนอนแน่นิ่งอยู่บนเก้าอี้...', 12.00, 4.7, 'active', '2026-10-21 13:34:36'),
(9, 'พลิกชะตาจักรพรรดิเวท', 'มังกรหยก', 'Fantasy', 'https://images.unsplash.com/photo-1514539079130-25950c84af65?w=500&q=80', 'มหากาพย์การต่อสู้เพื่อทวงคืนบัลลังก์ของจักรพรรดิแห่งอักขระเวท', 'บทที่ 1: การตื่นขึ้นในสุสานแร่ออรา\n\nละอองแสงสีฟ้าครามลอยอบอวลไปทั่วสุสานโบราณ...', 18.00, 5.0, 'active', '2026-10-21 13:34:36');

-- --------------------------------------------------------

--
-- Table structure for table `rentals`
--

CREATE TABLE `rentals` (
  `rental_id` int(11) NOT NULL,
  `user_id` int(11) NOT NULL,
  `novel_id` int(11) NOT NULL,
  `rent_days` int(11) NOT NULL,
  `total_price` decimal(10,2) NOT NULL,
  `rent_date` datetime DEFAULT current_timestamp(),
  `expire_date` datetime NOT NULL,
  `status` enum('active','expired','hidden') DEFAULT 'active',
  `created_at` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `rentals`
--

INSERT INTO `rentals` (`rental_id`, `user_id`, `novel_id`, `rent_days`, `total_price`, `rent_date`, `expire_date`, `status`, `created_at`) VALUES
(1, 8, 5, 30, 300.00, '2026-10-21 20:30:08', '2026-11-20 15:30:08', 'active', '2026-10-21 13:30:08');

-- --------------------------------------------------------

--
-- Table structure for table `topups`
--

CREATE TABLE `topups` (
  `topup_id` int(11) NOT NULL,
  `user_id` int(11) NOT NULL,
  `amount` decimal(10,2) NOT NULL,
  `slip_img` varchar(255) NOT NULL,
  `status` enum('pending','approved','rejected') DEFAULT 'pending',
  `created_at` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `topups`
--

INSERT INTO `topups` (`topup_id`, `user_id`, `amount`, `slip_img`, `status`, `created_at`) VALUES
(1, 8, 100.00, 'uploads/slips/slip_1792591685_5722.png', 'pending', '2026-10-21 14:08:05');

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

CREATE TABLE `users` (
  `user_id` int(11) NOT NULL,
  `username` varchar(50) NOT NULL,
  `email` varchar(100) NOT NULL,
  `password_hash` varchar(255) NOT NULL,
  `role` enum('user','admin') DEFAULT 'user',
  `wallet_balance` decimal(10,2) DEFAULT 0.00,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `users`
--

INSERT INTO `users` (`user_id`, `username`, `email`, `password_hash`, `role`, `wallet_balance`, `created_at`) VALUES
(1, 'admin', 'admin@example.com', '$2y$10$4.aU2uWv3R.43s1C8M80zeY9fN2hQYI/U8zWbK6xQ1E1m/sUfE3Sm', 'admin', 1000.00, '2026-10-20 15:02:44'),
(2, 'demo_user', 'user@example.com', '$2y$10$4.aU2uWv3R.43s1C8M80zeY9fN2hQYI/U8zWbK6xQ1E1m/sUfE3Sm', 'user', 500.00, '2026-10-20 15:02:44'),
(3, 'GOTWPHU', 'ptitv7799@gmail.com', '$2y$10$BU5njp2duS57U1lVpaJhrut7pRgwuCWfUyLs261Efqi13mp8IdPVO', 'user', 100.00, '2026-10-20 15:04:10'),
(8, 'adminphu', '6710510532@psu.ac.th', '$2y$10$BU5njp2duS57U1lVpaJhrut7pRgwuCWfUyLs261Efqi13mp8IdPVO', 'admin', 10000299.00, '2026-10-20 15:04:10');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `novels`
--
ALTER TABLE `novels`
  ADD PRIMARY KEY (`novel_id`);

--
-- Indexes for table `rentals`
--
ALTER TABLE `rentals`
  ADD PRIMARY KEY (`rental_id`),
  ADD KEY `user_id` (`user_id`),
  ADD KEY `novel_id` (`novel_id`);

--
-- Indexes for table `topups`
--
ALTER TABLE `topups`
  ADD PRIMARY KEY (`topup_id`),
  ADD KEY `user_id` (`user_id`);

--
-- Indexes for table `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`user_id`),
  ADD UNIQUE KEY `username` (`username`),
  ADD UNIQUE KEY `email` (`email`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `novels`
--
ALTER TABLE `novels`
  MODIFY `novel_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=10;

--
-- AUTO_INCREMENT for table `rentals`
--
ALTER TABLE `rentals`
  MODIFY `rental_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `topups`
--
ALTER TABLE `topups`
  MODIFY `topup_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `users`
--
ALTER TABLE `users`
  MODIFY `user_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=11;

--
-- Constraints for dumped tables
--

--
-- Constraints for table `rentals`
--
ALTER TABLE `rentals`
  ADD CONSTRAINT `rentals_ibfk_1` FOREIGN KEY (`user_id`) REFERENCES `users` (`user_id`) ON DELETE CASCADE,
  ADD CONSTRAINT `rentals_ibfk_2` FOREIGN KEY (`novel_id`) REFERENCES `novels` (`novel_id`) ON DELETE CASCADE;

--
-- Constraints for table `topups`
--
ALTER TABLE `topups`
  ADD CONSTRAINT `topups_ibfk_1` FOREIGN KEY (`user_id`) REFERENCES `users` (`user_id`) ON DELETE CASCADE;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
